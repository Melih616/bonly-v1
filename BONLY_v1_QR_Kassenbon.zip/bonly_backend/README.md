# BONLY v1 – QR-Kassenbon MVP

Enthält:
- mobile BONLY-Web-App
- echte QR-Token-Erzeugung beim Test-Checkout
- QR-Kamera mit `BarcodeDetector` (wenn vom Browser unterstützt)
- manuelle Token-Eingabe als Fallback
- Abruf eines digitalen Bons über `/api/receipts/:token`
- kurzlebige Tokens (10 Minuten)
- Test-Kasse und BONLY-Terminal
- lokale Fallback-Daten, wenn keine API erreichbar ist

## Lokal

```bash
node server.js
```

Dann `http://localhost:8787` öffnen.

## Vercel

`vercel.json` und `api/[...route].js` sind für einen einfachen Vercel-MVP enthalten. Die serverlose Demo-Speicherung liegt nur im Speicher einer Function-Instanz und ist **nicht produktionsgeeignet**. Für den Pilotbetrieb sollte danach ein dauerhaftes Backend (z. B. Postgres/KV) angeschlossen werden.

## Testablauf

1. „Testkauf an der Kasse auslösen“
2. BONLY-Terminal zeigt QR
3. QR mit einem zweiten Gerät oder der BONLY-App scannen
4. BONLY ruft den Bon über den Token ab
5. Bon wird angezeigt und lokal im Gerät gemerkt

Der QR-Code enthält nicht die vollständigen Bon- oder Zahlungsdaten.
